<head>
    
</head>

<body>
    <footer>
    <form action="../controller/logout.php" method="post">
        <input type="submit" value="Logout">
    </form>
</footer>


</body>

