<?php
include 'header.php';
?>
<!---End of nav ---->
        
        <section class="empty__page">

            <h2>
                About My Page
            </h2>
            <h7>
                we specialize in creating unforgettable events. Whether it’s a wedding, corporate function, or private celebration, our experienced team ensures every detail is taken care of. Our mission is to turn your vision into reality and deliver a seamless, stress-free experience. Let us make your next event extraordinary!
            </h7>
            
        </section>


<?php
include 'footer.php';
?>