
<footer>
            <div class="footer__socials">
                <h3>Follow Us</h3>
                    <li><a href="https://youtube.com" target="_blank"><i class="fab fa-youtube"></i></a></li>
                    <li><a href="https://facebook.com" target="_blank"><i class="fab fa-facebook"></i></a></li>
                    <li><a href="https://instagram.com" target="_blank"><i class="fab fa-instagram"></i></a></li>
                    <li><a href="https://linkedin.com" target="_blank"><i class="fab fa-linkedin"></i></a></li>
                    <li><a href="https://github.com" target="_blank"><i class="fab fa-github"></i></a></li>
            </div>
            <div class="container footer__container">
                <article>
                    <h4>Catagoris</h4>
                    <ul>
                        <li><a href="">Exhibitions</a></li>
                        <li><a href="">Festivals</a></li>
                        <li><a href="">Social Awareness</a></li>
                        <li><a href="">peronal Event</a></li>
                        <li><a href="">Cultural</a></li>
                        <li><a href="">Alumni</a></li>
                        <li><a href="">Sports</a></li>
                        <li><a href="">Eid festivals</a></li>
                        
                        
                    </ul>
                </article>

                <article>
                    <h4>Support</h4>
                    <ul>
                        <li><a href="">Online Support</a></li>
                        <li><a href="">Call Services</a></li>
                        <li><a href="">Social Support</a></li>
                        <li><a href="">Emails</a></li>
                        <li><a href="">Electricity</a></li>
                        <li><a href="">Location</a></li>
                        
                    </ul>
                </article>

                <article>
                    <h4>Blog</h4>
                    <ul>
                        <li><a href="">SAfety</a></li>
                        <li><a href="">Repair</a></li>
                        <li><a href="">Recent</a></li>
                        <li><a href="">Popular</a></li>
                        <li><a href="">Catagories</a></li>
                       
                        
                    </ul>
                </article>

                <article>
                    <h4>Permalinks</h4>
                    <ul>
                        <li><a href="">Home</a></li>
                        <li><a href="">Gallery</a></li>
                        <li><a href="">About</a></li>
                        <li><a href="">Contacts</a></li>
                        <li><a href="">Review</a></li>
                        <li><a href="">Event Guide</a></li>
                        <li><a href="">Package Plan</a></li>
                        
                        
                    </ul>
                </article>
            </div>
        </footer>
    </body>

</html>