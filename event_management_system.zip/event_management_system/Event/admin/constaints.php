<?php
if (!defined('ROOT_URL')) {
    define('ROOT_URL', "http://localhost/Event/");
}

$servername = "localhost";
$username = "rimi"; // Your database username
$password = "rimi123"; // Your database password
$dbname = "blog"; // Your database name
 