<?php
include 'header.php';
?>

<h5> Package Plane</h5>
<div class="event-container">
<!-- Cultural Event -->
<div class="event-card">
<img src="https://via.placeholder.com/80" alt="Cultural">
<h3>Cultural Event</h3>
<p>Details about Cultural events.</p>
<a href="purchase.php">PURCHASE</a>
</div>
<!-- Personal Event -->
<div class="event-card">
<img src="https://via.placeholder.com/80" alt="Personal">
<h3>Personal Event</h3>
<p>Details about Personal Events.</p>
<a href="purchase.php">PURCHASE</a>
</div>
<!-- Festivals Event -->
<div class="event-card">
<img src="https://via.placeholder.com/80" alt="Festivals">
<h3>Festivals Event</h3>
<p>Details about Festivals Events.</p>
<a href="purchase.php">PURCHASE</a>
</div>
<!-- Alumni Event -->
<div class="event-card">
<img src="https://via.placeholder.com/80" alt="Alumni">
<h3>Alumni Event</h3>
<p>Details about Alumni Events.</p>
<a href="purchase.php">PURCHASE</a>
</div>
<!-- Social Awareness Event -->
<div class="event-card">
<img src="https://via.placeholder.com/80" alt="Social Awareness">
<h3>Social Awareness Event</h3>
<p>Details about Social Awareness Events.</p>
<a href="purchase.php">PURCHASE</a>
</div>
<!-- Sports Event -->
<div class="event-card">
<img src="https://via.placeholder.com/80" alt="Sports">
<h3>Sports Event</h3>
<p>Details Sports Event.</p>
<a href="purchase.php">PURCHASE</a>
</div>
</div>
</body>
</html>