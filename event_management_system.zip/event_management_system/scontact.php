<?php
include 'header.php';
?>
<!---End of nav ---->
        
<div class="nav">
    <img src="../images/cultural.webp">
</div>
        <section class="empty__page">
            <h1>
                    Get in touch
            </h1>
            <h1>
                Let's Talk About Work
            </h1>
            <h1>
                Thank you for visiting .Explore more, Contact with us!!
            </h1>
        </section>
        

        <?php
include 'footer.php';
?>